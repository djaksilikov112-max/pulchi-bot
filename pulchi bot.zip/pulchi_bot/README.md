# 🏦 Pulchi Bot – Kredit Solishtirish Boti

O'zbekistondagi barcha bank kreditlari, mikrokreditlar va zaymlarni solishtiruvchi, 
AI yordamida mijozga eng mos kreditni tavsiya qiluvchi Telegram bot.

---

## 📁 Fayl Strukturasi

```
pulchi_bot/
├── main.py           # Bot ishga tushiruvchi fayl
├── config.py         # Konfiguratsiya
├── database.py       # SQLite ma'lumotlar bazasi
├── keyboards.py      # Telegram tugmalari
├── utils.py          # Kredit kalkulyator + AI maslahat
├── handlers/
│   ├── __init__.py
│   ├── user.py       # Foydalanuvchi handlerlari
│   └── admin.py      # Admin panel handlerlari
├── requirements.txt  # Python kutubxonalari
├── .env.example      # Muhit o'zgaruvchilar namunasi
└── README.md
```

---

## ⚙️ O'rnatish

### 1. Repozitoriyani klonlash
```bash
git clone https://github.com/yourusername/pulchi-bot.git
cd pulchi-bot
```

### 2. Virtual muhit yaratish
```bash
python3 -m venv venv
source venv/bin/activate        # Linux/Mac
# yoki
venv\Scripts\activate           # Windows
```

### 3. Kutubxonalarni o'rnatish
```bash
pip install -r requirements.txt
```

### 4. Muhit o'zgaruvchilarni sozlash
```bash
cp .env.example .env
nano .env    # yoki istagan matn muharriringiz bilan oching
```

`.env` faylida quyidagilarni to'ldiring:
- `BOT_TOKEN` – @BotFather dan oling
- `ANTHROPIC_API_KEY` – https://console.anthropic.com dan oling
- `ADMIN_IDS` – O'zingizning Telegram ID ingiz (@userinfobot dan bilib oling)

### 5. Botni ishga tushirish
```bash
python main.py
```

---

## 🔑 API Kalitlarini Olish

### Telegram Bot Token
1. Telegramda @BotFather ga yozing
2. `/newbot` buyrug'ini bering
3. Bot nomini kiriting: `Pulchi Bot`
4. Usernameni kiriting: `PulchiBot` (oxiri `bot` bilan tugashi kerak)
5. Token olinadi

### Anthropic API Key
1. https://console.anthropic.com ga kiring
2. Ro'yxatdan o'ting
3. API Keys bo'limida yangi kalit yarating
4. Kalit boshlanishi: `sk-ant-api03-...`

### Payme Merchant
1. https://merchant.paycom.uz ga kiring
2. Biznes ro'yxatdan o'ting
3. Merchant ID va Secret Key oling

### Click Merchant
1. https://my.click.uz ga kiring
2. Business bo'limiga o'ting
3. Service ID va Merchant ID oling

---

## 🤖 Bot Buyruqlari

### Foydalanuvchi uchun
| Buyruq | Tavsif |
|--------|--------|
| `/start` | Botni ishga tushirish |
| `/menu` | Asosiy menyu |
| `/help` | Yordam |
| `/profile` | Shaxsiy profil |

### Admin uchun
| Buyruq | Tavsif |
|--------|--------|
| `/admin` | Admin panel |
| `/stats` | Statistika |
| `/broadcast {matn}` | Hammaga xabar yuborish |
| `/update_rates` | Bank stavkalarini ko'rish |
| `/set_rate {id} {min} {max}` | Stavkani yangilash |
| `/confirm_pay {pay_id} {tx_id}` | To'lovni tasdiqlash |

---

## 💰 Monetizatsiya

| Obuna | Narx |
|-------|------|
| 1 kun | 1,990 so'm |
| Qayta ulanish | 1,690 so'm |
| 1 hafta | 9,990 so'm |

**To'lov tizimlari:** Payme, Click, Uzum Bank

---

## 🗃️ Ma'lumotlar Bazasi Jadvallari

- `users` – Foydalanuvchilar va obuna holati
- `banks` – Banklar va kredit stavkalari
- `credit_types` – Kredit turlari
- `deposits` – Depozit stavkalari
- `payments` – To'lovlar tarixi
- `ai_sessions` – AI suhbat tarixi
- `stats` – Bot statistikasi

---

## 🚀 Server ga Joylash (VPS)

### Systemd service (Linux)
```bash
sudo nano /etc/systemd/system/pulchi-bot.service
```

```ini
[Unit]
Description=Pulchi Telegram Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/pulchi-bot
Environment=PATH=/home/ubuntu/pulchi-bot/venv/bin
ExecStart=/home/ubuntu/pulchi-bot/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable pulchi-bot
sudo systemctl start pulchi-bot
sudo systemctl status pulchi-bot
```

### Loglarni ko'rish
```bash
sudo journalctl -u pulchi-bot -f
# yoki
tail -f bot.log
```

---

## 📞 Yordam
Muammo yuzaga kelsa: @pulchi_support ga yozing.
