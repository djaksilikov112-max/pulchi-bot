# ============================================================
# utils.py - Pulchi Bot yordamchi funksiyalar
# ============================================================

import json
import math
import logging
import anthropic
from typing import List, Dict, Optional
from config import config
from database import get_all_banks, get_banks_by_credit_type, save_ai_message, get_ai_history

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────
# Kredit kalkulyator
# ──────────────────────────────────────────────────────────────

def calculate_monthly_payment(principal: float, annual_rate: float, months: int) -> float:
    """Annuitet (teng to'lov) usulida oylik to'lovni hisoblaydi."""
    if annual_rate == 0:
        return principal / months
    monthly_rate = annual_rate / 100 / 12
    payment = principal * (monthly_rate * (1 + monthly_rate) ** months) / ((1 + monthly_rate) ** months - 1)
    return payment


def calculate_all_banks(amount: float, months: int, credit_type: str = None) -> List[Dict]:
    """
    Barcha banklarni hisoblaydi va natijalar ro'yxatini qaytaradi.
    credit_type berilsa, faqat shu turdagi kreditlarni ko'rsatadi.
    """
    if credit_type:
        banks = get_banks_by_credit_type(credit_type)
    else:
        banks = get_all_banks()

    results = []
    for bank in banks:
        # Miqdor va muddat chegarasini tekshirish
        if amount < bank["min_amount"] or amount > bank["max_amount"]:
            continue
        if months < bank["min_term"] or months > bank["max_term"]:
            continue

        # Min stavka bo'yicha hisoblash
        min_payment = calculate_monthly_payment(amount, bank["min_rate"], months)
        max_payment = calculate_monthly_payment(amount, bank["max_rate"], months)
        total_min   = min_payment * months
        total_max   = max_payment * months
        overpay_min = total_min - amount
        overpay_max = total_max - amount

        results.append({
            "bank_id":     bank["id"],
            "bank_name":   bank["name"],
            "emoji":       bank["logo_emoji"],
            "min_rate":    bank["min_rate"],
            "max_rate":    bank["max_rate"],
            "min_payment": min_payment,
        	"max_payment": max_payment,
            "total_min":   total_min,
            "total_max":   total_max,
            "overpay_min": overpay_min,
            "overpay_max": overpay_max,
            "phone":       bank["phone"],
            "website":     bank["website"],
        })

    results.sort(key=lambda x: x["min_payment"])
    return results


def format_calc_results(results: List[Dict], amount: float, months: int) -> str:
    """Hisob-kitob natijalarini chiroyli matn qilib formatlaydi."""
    if not results:
        return (
            "😔 Kechirasiz, berilgan parametrlar bo'yicha mos kredit topilmadi.\n"
            "Summa yoki muddatni o'zgartiring."
        )

    lines = [
        f"🧮 <b>Kredit Hisob-Kitobi</b>\n",
        f"💵 Summa: <b>{amount:,.0f} so'm</b>",
        f"📅 Muddat: <b>{months} oy</b>\n",
        f"🏆 <b>Eng Qulay Banklar (top 3):</b>\n",
    ]

    for i, r in enumerate(results[:3], 1):
        medal = ["🥇", "🥈", "🥉"][i - 1]
        lines.append(
            f"{medal} <b>{r['bank_name']}</b> {r['emoji']}\n"
            f"   📊 Stavka: {r['min_rate']}% – {r['max_rate']}%\n"
            f"   💳 Oylik to'lov: {r['min_payment']:,.0f} – {r['max_payment']:,.0f} so'm\n"
            f"   📈 Jami ortiqcha: {r['overpay_min']:,.0f} – {r['overpay_max']:,.0f} so'm\n"
            f"   📞 {r['phone']}\n"
        )

    if len(results) > 3:
        lines.append(f"\n📋 Jami {len(results)} ta bank sizga kredit berishi mumkin.")

    lines.append("\n💡 <i>Batafsil ma'lumot va ariza uchun bankni tanlang:</i>")
    return "\n".join(lines)


def format_money(amount: float) -> str:
    """Summani o'qilishi oson formatga o'tkazadi."""
    if amount >= 1_000_000_000:
        return f"{amount/1_000_000_000:.1f} mlrd so'm"
    if amount >= 1_000_000:
        return f"{amount/1_000_000:.1f} mln so'm"
    return f"{amount:,.0f} so'm"


# ──────────────────────────────────────────────────────────────
# AI Maslahatchi (Claude API)
# ──────────────────────────────────────────────────────────────

def get_banks_summary() -> str:
    """AI uchun barcha banklar haqida qisqacha ma'lumot."""
    banks = get_all_banks()
    lines = []
    for b in banks:
        ct = json.loads(b.get("credit_types") or "[]")
        lines.append(
            f"- {b['name']}: stavka {b['min_rate']}–{b['max_rate']}%, "
            f"summa {format_money(b['min_amount'])}–{format_money(b['max_amount'])}, "
            f"muddat {b['min_term']}–{b['max_term']} oy, "
            f"kredit turlari: {', '.join(ct)}, "
            f"talablar: {b['requirements']}"
        )
    return "\n".join(lines)


AI_SYSTEM_PROMPT = """Sen "Pulchi Bot" – O'zbekistondagi kredit va moliyaviy maslahat beruvchi AI yordamchisan.
Sening vazifang: foydalanuvchining holatini tahlil qilib, eng mos kredit variantlarini tavsiya qilish.

QOIDALAR:
1. Faqat o'zbek tilida javob ber (lotin alifbosida).
2. Foydalanuvchining yoshi, hududu, ish holati, maqsadi va byudjetini aniqlashga harakat qil.
3. Agar ma'lumot yetarli bo'lmasa – aniq savollar ber (bir vaqtda 1-2 ta savol).
4. Tavsiya berganda – har bir bank uchun foiz stavkasi, talablar va afzalliklarni ko'rsat.
5. Eng optimal variantni alohida ajratib ko'rsat (✅ belgi bilan).
6. Ijobiy va do'stona ohangda muloqot qil.
7. Kredit olish xavflari haqida ham qisqacha ogohlantir.

MAVJUD BANKLAR MA'LUMOTI:
{banks_info}

Har bir javobning oxirida foydalanuvchiga keyingi qadam nima qilish kerakligini ayt.
"""


async def ai_advise(user_id: int, user_message: str) -> str:
    """
    Claude AI orqali shaxsiylashtirilgan kredit maslahat beradi.
    Suhbat tarixini saqlaydi.
    """
    try:
        client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)

        # Suhbat tarixini olish
        history = get_ai_history(user_id, limit=12)

        # Foydalanuvchi xabarini tarixga qo'shish
        save_ai_message(user_id, "user", user_message)
        history.append({"role": "user", "content": user_message})

        # System prompt ni banklar ma'lumoti bilan to'ldirish
        system = AI_SYSTEM_PROMPT.format(banks_info=get_banks_summary())

        response = client.messages.create(
            model="claude-opus-4-5",
            max_tokens=1500,
            system=system,
            messages=history,
        )

        answer = response.content[0].text
        save_ai_message(user_id, "assistant", answer)
        return answer

    except anthropic.AuthenticationError:
        logger.error("Anthropic API key noto'g'ri!")
        return "❌ AI xizmatiga ulanishda xatolik. Iltimos, keyinroq urinib ko'ring."
    except Exception as e:
        logger.error(f"AI xatolik: {e}")
        return "❌ AI javob bera olmadi. Iltimos, keyinroq urinib ko'ring."


# ──────────────────────────────────────────────────────────────
# Kredit turi matnlari
# ──────────────────────────────────────────────────────────────

CREDIT_TYPE_INFO = {
    "micro": {
        "name": "💰 Mikrokredit",
        "desc": (
            "Mikrokredit – kichik miqdordagi qisqa muddatli kreditlar.\n\n"
            "<b>Kimlar uchun?</b>\n"
            "• Kichik biznes ochmoqchi bo'lganlar\n"
            "• Qishloq aholisi\n"
            "• Ishsiz fuqarolar\n\n"
            "<b>Asosiy shartlar:</b>\n"
            "• Summa: 500,000 – 100,000,000 so'm\n"
            "• Muddat: 3 – 60 oy\n"
            "• Stavka: 24% – 32% yillik"
        )
    },
    "business": {
        "name": "🏢 Biznes Kredit",
        "desc": (
            "Tadbirkorlik faoliyatini rivojlantirish uchun kredit.\n\n"
            "<b>Kimlar uchun?</b>\n"
            "• Mavjud tadbirkorlar\n"
            "• Biznes ochmoqchi bo'lganlar\n"
            "• YaTT va MChJ egalari\n\n"
            "<b>Asosiy shartlar:</b>\n"
            "• Summa: 5,000,000 – 2,000,000,000 so'm\n"
            "• Muddat: 12 – 120 oy\n"
            "• Stavka: 23% – 33% yillik"
        )
    },
    "ipoteka": {
        "name": "🏠 Ipoteka",
        "desc": (
            "Uy-joy sotib olish yoki qurish uchun uzoq muddatli kredit.\n\n"
            "<b>Kimlar uchun?</b>\n"
            "• Uy-joy sotib olmoqchi bo'lganlar\n"
            "• Yangi qurilish xonadorlari\n\n"
            "<b>Asosiy shartlar:</b>\n"
            "• Dastlabki to'lov: 20% dan\n"
            "• Summa: 50,000,000 so'mdan\n"
            "• Muddat: 60 – 240 oy (20 yilgacha)\n"
            "• Stavka: 25% – 28% yillik"
        )
    },
    "auto": {
        "name": "🚗 Avtokredit",
        "desc": (
            "Avtomobil sotib olish uchun kredit.\n\n"
            "<b>Kimlar uchun?</b>\n"
            "• Yangi avtomobil xarida qilmoqchi bo'lganlar\n"
            "• Haydovchilik guvohnomasi bor fuqarolar\n\n"
            "<b>Asosiy shartlar:</b>\n"
            "• Summa: 5,000,000 – 500,000,000 so'm\n"
            "• Muddat: 12 – 84 oy\n"
            "• Stavka: 28% – 32% yillik\n"
            "• Asaka Bank GM avtomobillari uchun maxsus taklif beradi"
        )
    },
    "unemployed": {
        "name": "📋 Ishsizlar uchun",
        "desc": (
            "Ishsiz fuqarolar uchun davlat dasturlari asosida kreditlar.\n\n"
            "<b>Dasturlar:</b>\n"
            "• <b>Temir daftar</b> – muhtoj oilalar uchun\n"
            "• <b>Ishga marhamat</b> – yangi ish o'rni ochish uchun\n"
            "• <b>Yoshlar startap</b> – 35 yoshgacha bo'lgan yoshlar uchun\n\n"
            "<b>Asosiy shartlar:</b>\n"
            "• Summa: 500,000 – 500,000,000 so'm\n"
            "• Muddat: 3 – 84 oy\n"
            "• Stavka: 24% – 27% (imtiyozli)"
        )
    },
}


# ──────────────────────────────────────────────────────────────
# Ariza yordamchisi
# ──────────────────────────────────────────────────────────────

def get_required_docs(bank_name: str, credit_type: str = "micro") -> str:
    """Bank va kredit turiga qarab kerakli hujjatlar."""
    base_docs = (
        "📄 <b>Asosiy hujjatlar:</b>\n"
        "1. Pasport (asl nusxa + fotokopiya)\n"
        "2. PINFL (shaxsiy identifikatsiya raqami)\n"
        "3. 3×4 fotosurat (2 ta)\n"
        "4. Ariza blanki (bankdan olinadi)\n"
    )

    type_docs = {
        "micro":      "\n💼 <b>Kredit uchun qo'shimcha:</b>\n5. Biznes-reja\n6. Garov hujjatlari (mol-mulk, kafillar)",
        "business":   "\n💼 <b>Biznes kredit uchun qo'shimcha:</b>\n5. Biznes-reja\n6. Soliq ro'yxatidan o'tish guvohnomasi\n7. Moliyaviy hisobot (6 oylik)\n8. Garov hujjatlari",
        "ipoteka":    "\n🏠 <b>Ipoteka uchun qo'shimcha:</b>\n5. Uy-joy hujjatlari\n6. Nikoh guvohnomasi\n7. Daromad ma'lumotnoması (ish joyidan)\n8. Dastlabki to'lov kvitansiyasi",
        "auto":       "\n🚗 <b>Avtokredit uchun qo'shimcha:</b>\n5. Haydovchilik guvohnomasi\n6. Avtomobil shartnomasi\n7. Dastlabki to'lov kvitansiyasi",
        "unemployed": "\n📋 <b>Ishsizlar dasturi uchun qo'shimcha:</b>\n5. Mehnat birjasidan ma'lumotnoma\n6. Oilaviy holat to'g'risida ma'lumotnoma\n7. Biznes-reja (oddiy shaklda)",
    }

    return base_docs + type_docs.get(credit_type, "")


def get_application_script(bank_name: str) -> str:
    """Bank bilan muloqot qilish uchun skript."""
    return (
        f"🗣️ <b>{bank_name} bilan muloqot skripti</b>\n\n"
        "Salom. Men kredit olish bo'yicha maslahat olmoqchi edim.\n\n"
        "<b>So'rashingiz kerak bo'lgan savollar:</b>\n"
        "1. «Hozir qanday kredit dasturlaringiz bor?»\n"
        "2. «Minimal foiz stavka qancha?»\n"
        "3. «Ariza ko'rib chiqish muddati necha kun?»\n"
        "4. «Garovsiz kredit berish imkoniyati bormi?»\n"
        "5. «Dastlabki to'lov talab qiladilarmi?»\n\n"
        "<b>Muhim eslatma:</b>\n"
        "• Bir kunda 2-3 ta bankka borish yaxshi\n"
        "• Barcha shartlarni yozib oling\n"
        "• Imzolashdan oldin shartnomasini diqqat bilan o'qing\n"
        "• Yashirin to'lovlar borligini so'rang"
    )
