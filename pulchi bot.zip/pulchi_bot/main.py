#!/usr/bin/env python3
# ============================================================
# main.py - Pulchi Bot – asosiy fayl
# ============================================================

import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from config import config
from database import init_db
from handlers import user, admin

# ── Logging sozlamasi ────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("bot.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)


async def main():
    # ── Ma'lumotlar bazasini ishga tushirish ─────────────────
    logger.info("📦 Ma'lumotlar bazasi ishga tushirilmoqda...")
    init_db()

    # ── Bot va Dispatcher ────────────────────────────────────
    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()

    # ── Router'larni ulash ────────────────────────────────────
    # Admin handler'larni avval ulaymiz (ustunlik uchun)
    dp.include_router(admin.router)
    dp.include_router(user.router)

    # ── Startup xabari ────────────────────────────────────────
    logger.info(f"🚀 {config.BOT_NAME} ishga tushdi!")
    for admin_id in config.ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                f"✅ <b>{config.BOT_NAME} ishga tushdi!</b>\n\n"
                f"🤖 Bot: {config.BOT_USERNAME}\n"
                f"📊 /admin – admin panel"
            )
        except Exception as e:
            logger.warning(f"Admin {admin_id} ga xabar yuborib bo'lmadi: {e}")

    # ── Polling ishga tushirish ───────────────────────────────
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()
        logger.info("Bot to'xtatildi.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot to'xtatildi (Ctrl+C).")
