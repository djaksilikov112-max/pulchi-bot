# ============================================================
# handlers/user.py - Foydalanuvchi handlerlari
# ============================================================

import logging
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

import database as db
import keyboards as kb
from utils import (
    calculate_all_banks, format_calc_results, format_money,
    CREDIT_TYPE_INFO, get_required_docs, get_application_script, ai_advise
)
from config import config

logger = logging.getLogger(__name__)
router = Router()


# ──────────────────────────────────────────────────────────────
# FSM holatlari
# ──────────────────────────────────────────────────────────────

class CalcStates(StatesGroup):
    waiting_amount  = State()
    waiting_months  = State()

class ProfileStates(StatesGroup):
    waiting_age     = State()

class AIStates(StatesGroup):
    chatting        = State()


# ──────────────────────────────────────────────────────────────
# /start
# ──────────────────────────────────────────────────────────────

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    user = message.from_user
    db.upsert_user(user.id, user.username, user.full_name)
    db.log_event("start", user.id)

    text = (
        f"👋 Salom, <b>{user.first_name}</b>!\n\n"
        f"🏦 <b>Pulchi Bot</b>ga xush kelibsiz!\n\n"
        "Men sizga O'zbekistondagi barcha banklarning kredit va omonat "
        "shartlarini solishtirish hamda <b>AI yordamida</b> sizga eng mos "
        "kreditni topishda yordam beraman.\n\n"
        "Quyidagi menyudan kerakli bo'limni tanlang 👇"
    )
    await message.answer(text, reply_markup=kb.main_menu_kb())


# ──────────────────────────────────────────────────────────────
# /menu va /help
# ──────────────────────────────────────────────────────────────

@router.message(Command("menu"))
async def cmd_menu(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("📋 Asosiy menyu:", reply_markup=kb.main_menu_kb())


@router.message(Command("help"))
async def cmd_help(message: Message):
    text = (
        "❓ <b>Yordam</b>\n\n"
        "🧮 <b>Kredit Kalkulyator</b> – Summa va muddatni kiriting, barcha banklarni solishtiramiz\n\n"
        "🤖 <b>AI Maslahatchi</b> – O'z holatingizni yozing, AI eng mos kreditni tavsiya qiladi\n\n"
        "💳 <b>Kredit Turlari</b> – Mikrokredit, Biznes, Ipoteka, Avtokredit va boshqalar\n\n"
        "💰 <b>Omonat Foizlari</b> – Banklarning depozit stavkalarini ko'ring\n\n"
        "📋 <b>Ariza Yordamchisi</b> – Kerakli hujjatlar va murojaat skripti (obuna kerak)\n\n"
        "<b>Muammo yuzaga keldimi?</b> @pulchi_support ga yozing."
    )
    await message.answer(text, reply_markup=kb.back_to_menu_kb())


# ──────────────────────────────────────────────────────────────
# Asosiy menyu callback
# ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "main_menu")
async def cb_main_menu(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.edit_text(
        "📋 <b>Asosiy Menyu</b>\n\nQuyidagidan tanlang 👇",
        reply_markup=kb.main_menu_kb()
    )


# ──────────────────────────────────────────────────────────────
# KREDIT KALKULYATOR
# ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "calc")
async def cb_calc_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(CalcStates.waiting_amount)
    await call.message.edit_text(
        "🧮 <b>Kredit Kalkulyator</b>\n\n"
        "Kredit summani kiriting (so'mda):\n\n"
        "<i>Masalan: 5000000 yoki 5 mln</i>",
        reply_markup=kb.back_to_menu_kb()
    )


@router.message(CalcStates.waiting_amount)
async def calc_get_amount(message: Message, state: FSMContext):
    text = message.text.strip().lower().replace(" ", "").replace(",", "")

    # "mln" yoki "mlrd" ni qabul qilish
    multiplier = 1
    if "mlrd" in text:
        multiplier = 1_000_000_000
        text = text.replace("mlrd", "")
    elif "mln" in text:
        multiplier = 1_000_000
        text = text.replace("mln", "")

    try:
        amount = float(text) * multiplier
        if amount < 500_000:
            await message.answer("❌ Minimal kredit summasi 500,000 so'm.\nQayta kiriting:")
            return
        if amount > 10_000_000_000:
            await message.answer("❌ Maksimal summa 10 mlrd so'm.\nQayta kiriting:")
            return
    except ValueError:
        await message.answer("❌ Noto'g'ri format. Raqam kiriting:\n<i>Masalan: 5000000</i>")
        return

    await state.update_data(amount=amount)
    await state.set_state(CalcStates.waiting_months)
    await message.answer(
        f"✅ Summa: <b>{format_money(amount)}</b>\n\n"
        "📅 Kredit muddatini kiriting (oyda):\n\n"
        "<i>Masalan: 12 (1 yil), 24 (2 yil), 60 (5 yil)</i>"
    )


@router.message(CalcStates.waiting_months)
async def calc_get_months(message: Message, state: FSMContext):
    try:
        months = int(message.text.strip())
        if months < 1 or months > 300:
            await message.answer("❌ Muddat 1 dan 300 oygacha bo'lishi kerak.\nQayta kiriting:")
            return
    except ValueError:
        await message.answer("❌ Noto'g'ri format. Faqat raqam kiriting:\n<i>Masalan: 24</i>")
        return

    data = await state.get_data()
    amount = data["amount"]
    await state.clear()

    # Hisoblaymiz
    results = calculate_all_banks(amount, months)
    result_text = format_calc_results(results, amount, months)
    db.log_event("calc_used", message.from_user.id)

    # Inline tugmalar – top 3 bankni tanlash
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for r in results[:5]:
        builder.row(InlineKeyboardButton(
            text=f"{r['emoji']} {r['bank_name']} – {r['min_payment']:,.0f} so'm/oy",
            callback_data=f"bank_detail_{r['bank_id']}"
        ))
    builder.row(InlineKeyboardButton(text="🔙 Menyu", callback_data="main_menu"))

    await message.answer(result_text, reply_markup=builder.as_markup())


# ──────────────────────────────────────────────────────────────
# KREDIT TURLARI
# ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "credit_types")
async def cb_credit_types(call: CallbackQuery):
    await call.message.edit_text(
        "💳 <b>Kredit Turlari</b>\n\nQaysi turdagi kredit qiziqtiradi?",
        reply_markup=kb.credit_types_kb()
    )


@router.callback_query(F.data.startswith("ct_"))
async def cb_credit_type_detail(call: CallbackQuery):
    code = call.data[3:]
    info = CREDIT_TYPE_INFO.get(code)
    if not info:
        await call.answer("Ma'lumot topilmadi", show_alert=True)
        return

    from database import get_banks_by_credit_type
    banks = get_banks_by_credit_type(code)

    text = f"{info['name']}\n\n{info['desc']}\n\n"
    text += f"🏦 <b>Ushbu kredit beruvchi banklar ({len(banks)} ta):</b>\n"
    for b in banks:
        text += f"• {b['logo_emoji']} {b['name']}: {b['min_rate']}–{b['max_rate']}%\n"

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(
        text=f"🧮 Bu turdagi kredit hisoblash",
        callback_data=f"calc_type_{code}"
    ))
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="credit_types"))
    await call.message.edit_text(text, reply_markup=builder.as_markup())


# ──────────────────────────────────────────────────────────────
# OMONAT FOIZLARI
# ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "deposits")
async def cb_deposits(call: CallbackQuery):
    banks = db.get_all_banks()
    text = "💰 <b>Omonat (Depozit) Stavkalari</b>\n\n"
    text += "📊 Taxminiy stavkalar (banklarga murojaat qiling aniq ma'lumot uchun):\n\n"

    for b in banks:
        text += (
            f"{b['logo_emoji']} <b>{b['name']}</b>\n"
            f"   UZS: taxminan {b['min_rate']-2:.0f}–{b['min_rate']:.0f}% yillik\n"
            f"   USD: taxminan 5–8% yillik\n\n"
        )

    text += "📞 <i>Aniq stavkalar uchun bevosita bankga murojaat qiling.</i>"

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🔙 Menyu", callback_data="main_menu"))
    await call.message.edit_text(text, reply_markup=builder.as_markup())


# ──────────────────────────────────────────────────────────────
# BANK BATAFSIL MA'LUMOTI
# ──────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("bank_detail_"))
async def cb_bank_detail(call: CallbackQuery):
    bank_id = int(call.data.split("_")[-1])
    bank = db.get_bank(bank_id)
    if not bank:
        await call.answer("Bank topilmadi", show_alert=True)
        return

    import json
    ct_list = json.loads(bank.get("credit_types") or "[]")
    ct_names = {"micro": "Mikrokredit", "business": "Biznes", "ipoteka": "Ipoteka", "auto": "Avtokredit", "unemployed": "Ishsizlar"}
    ct_str = ", ".join(ct_names.get(c, c) for c in ct_list)

    text = (
        f"{bank['logo_emoji']} <b>{bank['name']}</b>\n\n"
        f"📊 Stavka: <b>{bank['min_rate']}% – {bank['max_rate']}%</b> yillik\n"
        f"💵 Summa: {format_money(bank['min_amount'])} – {format_money(bank['max_amount'])}\n"
        f"📅 Muddat: {bank['min_term']} – {bank['max_term']} oy\n"
        f"💳 Kredit turlari: {ct_str}\n\n"
        f"📋 <b>Talablar:</b>\n{bank['requirements']}\n\n"
        f"✅ <b>Afzalliklar:</b>\n{bank['advantages']}\n\n"
        f"📞 Tel: {bank['phone']}\n"
        f"🌐 Sayt: {bank['website']}"
    )
    await call.message.edit_text(text, reply_markup=kb.bank_detail_kb(bank_id))


@router.callback_query(F.data.startswith("docs_"))
async def cb_bank_docs(call: CallbackQuery):
    bank_id = int(call.data.split("_")[-1])
    bank = db.get_bank(bank_id)

    # Obuna tekshirish
    if not db.is_subscribed(call.from_user.id):
        await call.message.edit_text(
            "🔒 <b>Bu funksiya faqat obuna a'zolari uchun!</b>\n\n"
            "📋 Ariza yordamchisi xizmati quyidagilarni o'z ichiga oladi:\n"
            "• Kerakli hujjatlar ro'yxati\n"
            "• Bank bilan muloqot skripti\n"
            "• Filial manzillari\n"
            "• Ko'rib chiqish muddati\n\n"
            f"💰 Bor-yo'g'i {config.PRICE_1_DAY:,} so'm/kun!",
            reply_markup=kb.subscription_kb(db.has_reconnect_discount(call.from_user.id))
        )
        return

    docs_text = get_required_docs(bank["name"] if bank else "")
    await call.message.edit_text(
        f"📄 <b>{bank['name']} uchun hujjatlar</b>\n\n{docs_text}",
        reply_markup=kb.bank_detail_kb(bank_id)
    )
    db.log_event("docs_viewed", call.from_user.id, str(bank_id))


@router.callback_query(F.data.startswith("script_"))
async def cb_bank_script(call: CallbackQuery):
    bank_id = int(call.data.split("_")[-1])
    bank = db.get_bank(bank_id)

    if not db.is_subscribed(call.from_user.id):
        await call.message.edit_text(
            "🔒 Bu funksiya obuna talab qiladi!",
            reply_markup=kb.subscription_kb(db.has_reconnect_discount(call.from_user.id))
        )
        return

    script = get_application_script(bank["name"] if bank else "Bank")
    await call.message.edit_text(script, reply_markup=kb.bank_detail_kb(bank_id))


@router.callback_query(F.data.startswith("branch_"))
async def cb_branch(call: CallbackQuery):
    bank_id = int(call.data.split("_")[-1])
    bank = db.get_bank(bank_id)

    if not db.is_subscribed(call.from_user.id):
        await call.message.edit_text(
            "🔒 Bu funksiya obuna talab qiladi!",
            reply_markup=kb.subscription_kb(db.has_reconnect_discount(call.from_user.id))
        )
        return

    text = (
        f"📍 <b>{bank['name']} filiallari</b>\n\n"
        f"📞 Yagona qo'ng'iroq markazi: <b>{bank['phone']}</b>\n"
        f"🌐 Sayt: {bank['website']}\n\n"
        f"<i>Eng yaqin filial manzilini sayt orqali yoki qo'ng'iroq markazi orqali bilib oling.</i>"
    )
    await call.message.edit_text(text, reply_markup=kb.bank_detail_kb(bank_id))


@router.callback_query(F.data.startswith("timing_"))
async def cb_timing(call: CallbackQuery):
    bank_id = int(call.data.split("_")[-1])
    bank = db.get_bank(bank_id)

    if not db.is_subscribed(call.from_user.id):
        await call.message.edit_text(
            "🔒 Bu funksiya obuna talab qiladi!",
            reply_markup=kb.subscription_kb(db.has_reconnect_discount(call.from_user.id))
        )
        return

    timings = {
        "Agrobank": "5–10 ish kuni",
        "Mikrokreditbank": "3–5 ish kuni",
        "Xalq Banki": "7–14 ish kuni",
        "Anor Bank": "1–3 ish kuni (onlayn)",
        "Kapitalbank": "3–7 ish kuni",
        "Ipoteka Bank": "10–15 ish kuni",
        "SQB (Sanoat Qurilish Bank)": "7–14 ish kuni",
        "Asaka Bank": "3–7 ish kuni",
        "Hamkorbank": "3–5 ish kuni",
        "Tenge Bank": "1–3 ish kuni (onlayn)",
    }
    bname = bank["name"] if bank else ""
    timing = timings.get(bname, "3–14 ish kuni")

    text = (
        f"⏱️ <b>{bname} – Ariza ko'rib chiqish muddati</b>\n\n"
        f"🕐 Taxminiy muddat: <b>{timing}</b>\n\n"
        "📝 <b>Jarayon bosqichlari:</b>\n"
        "1. Ariza topshirish\n"
        "2. Kredit tarixi tekshirish (1-2 kun)\n"
        "3. Garovni baholash (1-3 kun)\n"
        "4. Kredit qo'mitasi qarori (1-5 kun)\n"
        "5. Shartnoma imzolash\n"
        "6. Pul o'tkazilishi (1 kun)\n\n"
        "<i>⚡ Onlayn ariza berish jarayonni tezlashtiradi!</i>"
    )
    await call.message.edit_text(text, reply_markup=kb.bank_detail_kb(bank_id))


# ──────────────────────────────────────────────────────────────
# ARIZA YORDAMCHISI
# ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "application_helper")
async def cb_app_helper(call: CallbackQuery):
    if not db.is_subscribed(call.from_user.id):
        await call.message.edit_text(
            "🔒 <b>Ariza Yordamchisi – Pullik xizmat</b>\n\n"
            "Bu xizmat orqali siz quyidagilarni olasiz:\n"
            "✅ Tanlangan bank uchun kerakli hujjatlar ro'yxati\n"
            "✅ Bank xodimi bilan gaplashish uchun tayyor skript\n"
            "✅ Eng yaqin filial manzili va ish vaqti\n"
            "✅ Ariza ko'rib chiqilish muddati\n"
            "✅ Yashirin xarajatlardan ogohlantirish\n\n"
            f"💎 <b>Obuna narxlari:</b>\n"
            f"• 1 kun: {config.PRICE_1_DAY:,} so'm\n"
            f"• 1 hafta: {config.PRICE_WEEKLY:,} so'm",
            reply_markup=kb.subscription_kb(db.has_reconnect_discount(call.from_user.id))
        )
        return

    banks = db.get_all_banks()
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    for b in banks[:10]:
        builder.row(InlineKeyboardButton(
            text=f"{b['logo_emoji']} {b['name']}",
            callback_data=f"bank_detail_{b['id']}"
        ))
    builder.row(InlineKeyboardButton(text="🔙 Menyu", callback_data="main_menu"))
    await call.message.edit_text(
        "📋 <b>Ariza Yordamchisi</b>\n\nQaysi bank uchun yordam kerak?",
        reply_markup=builder.as_markup()
    )


# ──────────────────────────────────────────────────────────────
# PROFIL
# ──────────────────────────────────────────────────────────────

@router.message(Command("profile"))
@router.callback_query(F.data == "my_profile")
async def show_profile(event, state: FSMContext = None):
    if isinstance(event, CallbackQuery):
        user_id = event.from_user.id
        send = event.message.edit_text
    else:
        user_id = event.from_user.id
        send = event.answer

    user = db.get_user(user_id)
    if not user:
        db.upsert_user(user_id)
        user = db.get_user(user_id)

    sub_status = "✅ Faol" if db.is_subscribed(user_id) else "❌ Faol emas"
    sub_type_map = {"1day": "1 kunlik", "3day": "3 kunlik", "weekly": "Haftalik", None: "—"}
    emp_map = {"employed": "Ishlayman", "unemployed": "Ishsizman", "entrepreneur": "Tadbirkorman", None: "Kiritilmagan"}

    text = (
        f"👤 <b>Mening Profilim</b>\n\n"
        f"🆔 ID: <code>{user_id}</code>\n"
        f"👤 Ism: {user.get('full_name') or '—'}\n"
        f"🎂 Yosh: {user.get('age') or 'Kiritilmagan'}\n"
        f"📍 Hudud: {user.get('region') or 'Kiritilmagan'}\n"
        f"💼 Ish holati: {emp_map.get(user.get('employment'))}\n\n"
        f"💎 <b>Obuna holati:</b> {sub_status}\n"
        f"📦 Turi: {sub_type_map.get(user.get('sub_type'))}\n"
    )
    if user.get("sub_expires"):
        text += f"📅 Tugash: {user['sub_expires'][:16]}\n"

    await send(text, reply_markup=kb.profile_kb(db.is_subscribed(user_id)))


@router.callback_query(F.data == "edit_profile")
async def cb_edit_profile(call: CallbackQuery):
    await call.message.edit_text(
        "✏️ <b>Profilni tahrirlash</b>\n\nNimani o'zgartirmoqchisiz?",
        reply_markup=kb.edit_profile_kb()
    )


@router.callback_query(F.data == "ep_age")
async def cb_ep_age(call: CallbackQuery, state: FSMContext):
    await state.set_state(ProfileStates.waiting_age)
    await call.message.edit_text("🎂 Yoshingizni kiriting (raqamda):\n<i>Masalan: 35</i>")


@router.message(ProfileStates.waiting_age)
async def profile_get_age(message: Message, state: FSMContext):
    try:
        age = int(message.text.strip())
        if age < 16 or age > 100:
            await message.answer("❌ Yoshingiz 16 dan 100 gacha bo'lishi kerak.")
            return
    except ValueError:
        await message.answer("❌ Faqat raqam kiriting.")
        return

    db.update_user_profile(message.from_user.id, age=age)
    await state.clear()
    await message.answer(f"✅ Yosh saqlandi: <b>{age}</b>", reply_markup=kb.edit_profile_kb())


@router.callback_query(F.data == "ep_region")
async def cb_ep_region(call: CallbackQuery):
    await call.message.edit_text(
        "📍 Hududingizni tanlang:",
        reply_markup=kb.regions_kb()
    )


@router.callback_query(F.data.startswith("region_"))
async def cb_set_region(call: CallbackQuery):
    region = call.data[7:]
    db.update_user_profile(call.from_user.id, region=region)
    await call.message.edit_text(
        f"✅ Hudud saqlandi: <b>{region}</b>",
        reply_markup=kb.edit_profile_kb()
    )


@router.callback_query(F.data == "ep_employment")
async def cb_ep_employment(call: CallbackQuery):
    await call.message.edit_text(
        "💼 Ish holatini tanlang:",
        reply_markup=kb.employment_kb()
    )


@router.callback_query(F.data.startswith("emp_"))
async def cb_set_employment(call: CallbackQuery):
    emp = call.data[4:]
    db.update_user_profile(call.from_user.id, employment=emp)
    names = {"employed": "Ishlayman", "unemployed": "Ishsizman", "entrepreneur": "Tadbirkorman"}
    await call.message.edit_text(
        f"✅ Ish holati saqlandi: <b>{names.get(emp, emp)}</b>",
        reply_markup=kb.edit_profile_kb()
    )


# ──────────────────────────────────────────────────────────────
# AI MASLAHATCHI
# ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "ai_advisor")
async def cb_ai_advisor(call: CallbackQuery, state: FSMContext):
    await state.set_state(AIStates.chatting)
    await call.message.edit_text(
        "🤖 <b>AI Kredit Maslahatchi</b>\n\n"
        "Men sizning holatingizni tahlil qilib, eng mos kredit variantlarini tavsiya qilaman.\n\n"
        "📝 O'zingiz haqingizda yozing:\n\n"
        "<i>Masalan: «45 yosh, Nukus shahri, tovuq boqish uchun 30 mln kredit kerak, ishsizman»</i>\n\n"
        "Qanchalik ko'proq ma'lumot bersangiz, shunchalik aniq tavsiya beraman! 👇"
    )
    db.log_event("ai_used", call.from_user.id)


@router.callback_query(F.data == "ai_new")
async def cb_ai_new(call: CallbackQuery, state: FSMContext):
    db.clear_ai_history(call.from_user.id)
    await state.set_state(AIStates.chatting)
    await call.message.edit_text(
        "🔄 <b>Yangi suhbat boshlandi!</b>\n\n"
        "O'zingiz haqingizda yozing 👇"
    )


@router.message(AIStates.chatting)
async def ai_chat(message: Message, state: FSMContext):
    # "typing..." ko'rsatish
    await message.bot.send_chat_action(message.chat.id, "typing")

    # AI javob olish
    answer = await ai_advise(message.from_user.id, message.text)
    await message.answer(answer, reply_markup=kb.ai_actions_kb())


# ──────────────────────────────────────────────────────────────
# OBUNA
# ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "subscription")
async def cb_subscription(call: CallbackQuery):
    has_discount = db.has_reconnect_discount(call.from_user.id)
    discount_text = ""
    if has_discount:
        discount_text = (
            f"\n\n⚡ <b>Siz uchun maxsus taklif!</b>\n"
            f"Qayta ulanish chegirmasi: <b>1 kun = {config.PRICE_RECONNECT:,} so'm</b>"
        )

    text = (
        f"💎 <b>Pulchi Bot Obunasi</b>\n\n"
        f"Obuna orqali siz quyidagilardan foydalanasiz:\n"
        f"✅ Ariza yordamchisi (hujjatlar, skript)\n"
        f"✅ Filial manzillari\n"
        f"✅ Ko'rib chiqish muddati\n\n"
        f"💰 <b>Narxlar:</b>\n"
        f"• 1 kun: {config.PRICE_1_DAY:,} so'm\n"
        f"• 1 hafta: {config.PRICE_WEEKLY:,} so'm"
        f"{discount_text}"
    )
    await call.message.edit_text(text, reply_markup=kb.subscription_kb(has_discount))


@router.callback_query(F.data.startswith("sub_"))
async def cb_sub_choose(call: CallbackQuery):
    parts = call.data.split("_")
    # sub_1day / sub_weekly / sub_1day_discount
    sub_type = parts[1]
    is_discount = len(parts) > 2 and parts[2] == "discount"

    price_map = {
        "1day":   config.PRICE_RECONNECT if is_discount else config.PRICE_1_DAY,
        "weekly": config.PRICE_WEEKLY,
    }
    name_map = {"1day": "1 kunlik", "weekly": "Haftalik"}

    price = price_map.get(sub_type, config.PRICE_1_DAY)
    name  = name_map.get(sub_type, "1 kunlik")

    await call.message.edit_text(
        f"💳 <b>{name} obuna – {price:,} so'm</b>\n\n"
        f"To'lov usulini tanlang:",
        reply_markup=kb.payment_method_kb(sub_type)
    )


@router.callback_query(F.data.startswith("pay_"))
async def cb_pay(call: CallbackQuery):
    _, provider, sub_type = call.data.split("_", 2)
    price_map = {"1day": config.PRICE_1_DAY, "3day": config.PRICE_3_DAY, "weekly": config.PRICE_WEEKLY}
    amount = price_map.get(sub_type, config.PRICE_1_DAY)

    # To'lov ID yaratamiz
    payment_id = db.create_payment(call.from_user.id, provider, amount, sub_type)

    provider_texts = {
        "payme": (
            f"💳 <b>Payme orqali to'lov</b>\n\n"
            f"Miqdor: <b>{amount:,} so'm</b>\n"
            f"To'lov ID: <code>{payment_id}</code>\n\n"
            f"🔗 To'lov havolasi:\n"
            f"<code>https://checkout.paycom.uz/{config.PAYME_MERCHANT_ID}?amount={amount*100}&order_id={payment_id}</code>\n\n"
            f"⚠️ To'lovdan so'ng /start bosing yoki admin bilan bog'laning."
        ),
        "click": (
            f"💳 <b>Click orqali to'lov</b>\n\n"
            f"Miqdor: <b>{amount:,} so'm</b>\n"
            f"To'lov ID: <code>{payment_id}</code>\n\n"
            f"🔗 To'lov havolasi:\n"
            f"<code>https://my.click.uz/services/pay?service_id={config.CLICK_SERVICE_ID}&merchant_id={config.CLICK_MERCHANT_ID}&amount={amount}&transaction_param={payment_id}</code>\n\n"
            f"⚠️ To'lovdan so'ng /start bosing yoki admin bilan bog'laning."
        ),
        "uzum": (
            f"🏦 <b>Uzum Bank orqali to'lov</b>\n\n"
            f"Miqdor: <b>{amount:,} so'm</b>\n"
            f"To'lov ID: <code>{payment_id}</code>\n\n"
            f"📲 Uzum Bank ilovasi orqali quyidagi hisob raqamiga o'tkazing:\n"
            f"<code>8600XXXXXXXXXXXXXXXX</code>\n"
            f"Izoh: <code>Pulchi {payment_id}</code>\n\n"
            f"⚠️ To'lovdan so'ng chekni admin @pulchi_support ga yuboring."
        ),
    }

    text = provider_texts.get(provider, "To'lov tizimi vaqtincha ishlamayapti.")

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="✅ To'lovni tekshirish", callback_data=f"check_pay_{payment_id}"))
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="subscription"))
    await call.message.edit_text(text, reply_markup=builder.as_markup())


@router.callback_query(F.data.startswith("check_pay_"))
async def cb_check_payment(call: CallbackQuery):
    """
    Haqiqiy loyihada bu yerda Payme/Click API si tekshiriladi.
    Hozircha demo: adminlar qo'lda tasdiqlaydi.
    """
    payment_id = int(call.data.split("_")[-1])
    await call.answer(
        "⏳ To'lov tekshirilmoqda...\nAdmin tasdiqlashidan so'ng obuna faollashadi.",
        show_alert=True
    )


# ──────────────────────────────────────────────────────────────
# Yordam callback
# ──────────────────────────────────────────────────────────────

@router.callback_query(F.data == "help")
async def cb_help(call: CallbackQuery):
    text = (
        "❓ <b>Yordam</b>\n\n"
        "🧮 <b>Kredit Kalkulyator</b> – Summa va muddatni kiriting\n"
        "🤖 <b>AI Maslahatchi</b> – O'z holatingizni yozing\n"
        "💳 <b>Kredit Turlari</b> – Barcha kredit turlarini ko'ring\n"
        "💰 <b>Omonat Foizlari</b> – Depozit stavkalarini solishtiring\n"
        "📋 <b>Ariza Yordamchisi</b> – Obuna a'zolari uchun\n\n"
        "📞 Muammo bo'lsa: @pulchi_support"
    )
    await call.message.edit_text(text, reply_markup=kb.back_to_menu_kb())
