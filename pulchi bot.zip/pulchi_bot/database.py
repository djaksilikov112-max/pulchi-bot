# ============================================================
# database.py - Pulchi Bot ma'lumotlar bazasi
# ============================================================

import sqlite3
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from config import config

logger = logging.getLogger(__name__)


def get_connection() -> sqlite3.Connection:
    """SQLite ulanish qaytaradi, row_factory yoqilgan."""
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


# ──────────────────────────────────────────────────────────────
# Jadvallarni yaratish
# ──────────────────────────────────────────────────────────────

def init_db():
    """Barcha jadvallarni yaratadi va boshlang'ich ma'lumotlarni kiritadi."""
    with get_connection() as conn:
        c = conn.cursor()

        # Foydalanuvchilar
        c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id       INTEGER PRIMARY KEY,
                username      TEXT,
                full_name     TEXT,
                phone         TEXT,
                age           INTEGER,
                region        TEXT,
                employment    TEXT,      -- 'employed' | 'unemployed' | 'entrepreneur'
                is_subscribed INTEGER DEFAULT 0,
                sub_type      TEXT,      -- '1day' | '3day' | 'weekly'
                sub_expires   TEXT,      -- ISO datetime
                prev_sub_end  TEXT,      -- Oxirgi obuna tugagan vaqt (qayta ulanish chegirma)
                created_at    TEXT DEFAULT (datetime('now')),
                last_active   TEXT DEFAULT (datetime('now'))
            )
        """)

        # Banklar
        c.execute("""
            CREATE TABLE IF NOT EXISTS banks (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                name          TEXT NOT NULL,
                short_name    TEXT,
                logo_emoji    TEXT DEFAULT '🏦',
                credit_types  TEXT,      -- JSON list: ["micro","business","ipoteka"]
                min_rate      REAL,      -- Eng past foiz (%)
                max_rate      REAL,      -- Eng yuqori foiz (%)
                min_amount    INTEGER,   -- So'm
                max_amount    INTEGER,   -- So'm
                min_term      INTEGER,   -- Oy
                max_term      INTEGER,   -- Oy
                requirements  TEXT,      -- Talab (matn)
                advantages    TEXT,      -- Afzalliklar
                regions       TEXT,      -- Ishlash hududlari (JSON list)
                phone         TEXT,
                website       TEXT,
                is_active     INTEGER DEFAULT 1,
                updated_at    TEXT DEFAULT (datetime('now'))
            )
        """)

        # Kredit turlari
        c.execute("""
            CREATE TABLE IF NOT EXISTS credit_types (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                code        TEXT UNIQUE NOT NULL,   -- 'micro','business','ipoteka','auto','unemployed'
                name        TEXT NOT NULL,
                description TEXT,
                emoji       TEXT DEFAULT '💳'
            )
        """)

        # Omonat/Depozit stavkalari
        c.execute("""
            CREATE TABLE IF NOT EXISTS deposits (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                bank_id     INTEGER REFERENCES banks(id),
                currency    TEXT DEFAULT 'UZS',     -- 'UZS' | 'USD'
                min_rate    REAL,
                max_rate    REAL,
                min_amount  INTEGER,
                min_term    INTEGER,
                max_term    INTEGER,
                updated_at  TEXT DEFAULT (datetime('now'))
            )
        """)

        # To'lovlar tarixi
        c.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER REFERENCES users(user_id),
                provider      TEXT,       -- 'payme' | 'click' | 'uzum'
                transaction_id TEXT,
                amount        INTEGER,
                sub_type      TEXT,
                status        TEXT DEFAULT 'pending',  -- 'pending'|'paid'|'failed'
                created_at    TEXT DEFAULT (datetime('now')),
                paid_at       TEXT
            )
        """)

        # AI suhbat tarixi
        c.execute("""
            CREATE TABLE IF NOT EXISTS ai_sessions (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    INTEGER REFERENCES users(user_id),
                role       TEXT,      -- 'user' | 'assistant'
                message    TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            )
        """)

        # Statistika
        c.execute("""
            CREATE TABLE IF NOT EXISTS stats (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                event      TEXT,      -- 'calc_used' | 'ai_used' | 'sub_bought' | ...
                user_id    INTEGER,
                data       TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            )
        """)

        conn.commit()

    _seed_data()
    logger.info("✅ Ma'lumotlar bazasi tayyor.")


def _seed_data():
    """Boshlang'ich bank va kredit turi ma'lumotlarini kiritadi."""
    with get_connection() as conn:
        c = conn.cursor()

        # Kredit turlari
        types = [
            ("micro",      "Mikrokredit",         "Kichik miqdordagi qisqa muddatli kredit", "💰"),
            ("business",   "Biznes kredit",        "Tadbirkorlik uchun kredit",               "🏢"),
            ("ipoteka",    "Ipoteka",              "Uy-joy sotib olish uchun kredit",          "🏠"),
            ("auto",       "Avtokredit",           "Avtomobil sotib olish uchun kredit",       "🚗"),
            ("unemployed", "Ishsizlar uchun",      "Temir daftar, Ishga marhamat dasturlari",  "📋"),
        ]
        c.executemany("""
            INSERT OR IGNORE INTO credit_types (code, name, description, emoji)
            VALUES (?,?,?,?)
        """, types)

        # Banklar
        banks = [
            # (name, short, emoji, credit_types_json, min_rate, max_rate,
            #  min_amount, max_amount, min_term, max_term,
            #  requirements, advantages, regions_json, phone, website)
            (
                "Agrobank", "Agrobank", "🌾",
                '["micro","unemployed","business"]',
                24.0, 28.0, 1_000_000, 500_000_000, 6, 84,
                "O'zbekiston fuqarosi, 18-65 yosh, qishloq xo'jaligi bilan shug'ullanish",
                "Temir daftar, Ishga marhamat dasturlari, qishloq xo'jaligi uchun imtiyozli stavkalar",
                '["Toshkent","Samarqand","Farg\'ona","Andijon","Namangan","Buxoro","Xorazm","Qashqadaryo","Surxondaryo","Sirdaryo","Jizzax","Navoiy","Qoraqalpog\'iston"]',
                "1200", "https://agrobank.uz"
            ),
            (
                "Mikrokreditbank", "MKB", "🏦",
                '["micro","unemployed"]',
                27.0, 32.0, 500_000, 100_000_000, 3, 60,
                "O'zbekiston fuqarosi, 18-60 yosh, ishsizlik bo'yicha ro'yxatda turish mumkin",
                "Ishsizlar uchun maxsus dasturlar, tez ko'rib chiqish (3 ish kuni)",
                '["Toshkent","Samarqand","Farg\'ona","Andijon","Namangan","Buxoro","Nukus"]',
                "1202", "https://mikrokreditbank.uz"
            ),
            (
                "Xalq Banki", "Xalq", "🏛️",
                '["micro","business","ipoteka"]',
                29.0, 33.0, 1_000_000, 1_000_000_000, 12, 120,
                "O'zbekiston fuqarosi, 18-65 yosh, rasmiy ish joyi yoki biznes",
                "Keng tarmoq, davlat kafolati, tadbirkorlar uchun subsidiyalar",
                '["Toshkent","Samarqand","Farg\'ona","Andijon","Namangan","Buxoro","Xorazm","Qashqadaryo","Surxondaryo","Sirdaryo","Jizzax","Navoiy","Qoraqalpog\'iston"]',
                "1209", "https://xb.uz"
            ),
            (
                "Anor Bank", "Anor", "🍎",
                '["micro","business","auto"]',
                27.0, 31.0, 1_000_000, 300_000_000, 6, 60,
                "O'zbekiston fuqarosi, 21-65 yosh, onlayn ariza mumkin",
                "To'liq onlayn ariza, tez javob (1-2 ish kuni), mobil ilova",
                '["Toshkent","Samarqand","Farg\'ona","Andijon","Namangan"]',
                "71 200-00-00", "https://anorbank.uz"
            ),
            (
                "Kapitalbank", "Kapital", "💼",
                '["micro","business","auto","ipoteka"]',
                26.0, 30.0, 2_000_000, 500_000_000, 6, 84,
                "O'zbekiston fuqarosi, 21-65 yosh, daromad tasdiqlovchi hujjat",
                "Barcha kredit turlari, qulay shartlar, onlayn ariza",
                '["Toshkent","Samarqand","Farg\'ona","Andijon","Namangan","Buxoro"]',
                "78 140-00-00", "https://kapitalbank.uz"
            ),
            (
                "Ipoteka Bank", "Ipoteka", "🏠",
                '["ipoteka","business"]',
                25.0, 28.0, 50_000_000, 3_000_000_000, 60, 240,
                "O'zbekiston fuqarosi, 21-65 yosh, dastlabki to'lov 20%",
                "Ipotekaga ixtisoslashgan, eng qulay stavkalar, davlat dasturlari",
                '["Toshkent","Samarqand","Farg\'ona","Andijon","Namangan","Buxoro","Xorazm","Qashqadaryo","Surxondaryo"]',
                "1212", "https://ipotekabank.uz"
            ),
            (
                "SQB (Sanoat Qurilish Bank)", "SQB", "🏗️",
                '["business","auto","ipoteka"]',
                23.0, 27.0, 5_000_000, 2_000_000_000, 12, 120,
                "O'zbekiston fuqarosi yoki yuridik shaxs, 21-65 yosh, biznes rejasi",
                "Eng past stavkalar, qurilish va sanoat uchun maxsus dasturlar",
                '["Toshkent","Samarqand","Farg\'ona","Andijon","Namangan","Buxoro","Xorazm"]',
                "1203", "https://sqb.uz"
            ),
            (
                "Asaka Bank", "Asaka", "🚗",
                '["auto","business","micro"]',
                28.0, 32.0, 5_000_000, 500_000_000, 12, 84,
                "O'zbekiston fuqarosi, 21-60 yosh, avtokredit uchun haydovchilik guvohnomasi",
                "Avtokreditga ixtisoslashgan, GM avtomobillari uchun maxsus dasturlar",
                '["Toshkent","Samarqand","Farg\'ona","Andijon","Namangan","Buxoro"]',
                "71 207-00-00", "https://asakabank.uz"
            ),
            (
                "Hamkorbank", "Hamkor", "🤝",
                '["micro","business","unemployed"]',
                26.0, 30.0, 500_000, 200_000_000, 3, 60,
                "O'zbekiston fuqarosi, 18-63 yosh, mikro biznes uchun qulay",
                "Mikrokredit va SMB uchun ixtisoslashgan, tez ariza ko'rib chiqish",
                '["Toshkent","Samarqand","Farg\'ona","Andijon","Namangan","Buxoro","Xorazm","Qashqadaryo"]',
                "71 202-07-77", "https://hamkorbank.uz"
            ),
            (
                "Tenge Bank", "Tenge", "💳",
                '["micro","business","auto"]',
                25.0, 29.0, 1_000_000, 300_000_000, 6, 72,
                "O'zbekiston fuqarosi, 21-63 yosh, onlayn ariza",
                "Onlayn xizmatlar, raqamli bank, tez ko'rib chiqish",
                '["Toshkent","Samarqand","Farg\'ona","Andijon"]',
                "71 200-10-10", "https://tengebank.uz"
            ),
        ]
        c.executemany("""
            INSERT OR IGNORE INTO banks
            (name, short_name, logo_emoji, credit_types, min_rate, max_rate,
             min_amount, max_amount, min_term, max_term,
             requirements, advantages, regions, phone, website)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, banks)

        conn.commit()


# ──────────────────────────────────────────────────────────────
# Foydalanuvchi CRUD
# ──────────────────────────────────────────────────────────────

def get_user(user_id: int) -> Optional[Dict]:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        return dict(row) if row else None


def upsert_user(user_id: int, username: str = None, full_name: str = None):
    """Foydalanuvchini yaratadi yoki last_active ni yangilaydi."""
    with get_connection() as conn:
        existing = conn.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,)).fetchone()
        if existing:
            conn.execute(
                "UPDATE users SET last_active=datetime('now'), username=COALESCE(?,username), full_name=COALESCE(?,full_name) WHERE user_id=?",
                (username, full_name, user_id)
            )
        else:
            conn.execute(
                "INSERT INTO users (user_id, username, full_name) VALUES (?,?,?)",
                (user_id, username, full_name)
            )
        conn.commit()


def update_user_profile(user_id: int, **kwargs):
    """Profil maydonlarini yangilaydi."""
    if not kwargs:
        return
    fields = ", ".join(f"{k}=?" for k in kwargs)
    values = list(kwargs.values()) + [user_id]
    with get_connection() as conn:
        conn.execute(f"UPDATE users SET {fields} WHERE user_id=?", values)
        conn.commit()


def is_subscribed(user_id: int) -> bool:
    """Obuna faolligini tekshiradi."""
    user = get_user(user_id)
    if not user or not user["is_subscribed"]:
        return False
    if user["sub_expires"]:
        try:
            exp = datetime.fromisoformat(user["sub_expires"])
            if datetime.now() > exp:
                # Muddati o'tgan – obunani o'chirish
                with get_connection() as conn:
                    conn.execute(
                        "UPDATE users SET is_subscribed=0, prev_sub_end=sub_expires WHERE user_id=?",
                        (user_id,)
                    )
                    conn.commit()
                return False
        except Exception:
            pass
    return True


def activate_subscription(user_id: int, sub_type: str):
    """Obunani faollashtiradi."""
    days_map = {"1day": 1, "3day": 3, "weekly": 7}
    days = days_map.get(sub_type, 1)
    expires = (datetime.now() + timedelta(days=days)).isoformat()
    with get_connection() as conn:
        conn.execute("""
            UPDATE users
            SET is_subscribed=1, sub_type=?, sub_expires=?
            WHERE user_id=?
        """, (sub_type, expires, user_id))
        conn.commit()


def has_reconnect_discount(user_id: int) -> bool:
    """3 kundan keyin qayta ulashda chegirma borligini tekshiradi."""
    user = get_user(user_id)
    if not user or not user["prev_sub_end"]:
        return False
    try:
        prev = datetime.fromisoformat(user["prev_sub_end"])
        diff = datetime.now() - prev
        return 0 < diff.days <= 7   # 1-7 kun oralig'ida chegirma
    except Exception:
        return False


# ──────────────────────────────────────────────────────────────
# Bank CRUD
# ──────────────────────────────────────────────────────────────

def get_all_banks(active_only=True) -> List[Dict]:
    cond = "WHERE is_active=1" if active_only else ""
    with get_connection() as conn:
        rows = conn.execute(f"SELECT * FROM banks {cond} ORDER BY min_rate").fetchall()
        return [dict(r) for r in rows]


def get_bank(bank_id: int) -> Optional[Dict]:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM banks WHERE id=?", (bank_id,)).fetchone()
        return dict(row) if row else None


def update_bank_rate(bank_id: int, min_rate: float, max_rate: float):
    with get_connection() as conn:
        conn.execute(
            "UPDATE banks SET min_rate=?, max_rate=?, updated_at=datetime('now') WHERE id=?",
            (min_rate, max_rate, bank_id)
        )
        conn.commit()


def get_banks_by_credit_type(credit_type_code: str) -> List[Dict]:
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM banks WHERE credit_types LIKE ? AND is_active=1 ORDER BY min_rate",
            (f"%{credit_type_code}%",)
        ).fetchall()
        return [dict(r) for r in rows]


def get_deposits() -> List[Dict]:
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT d.*, b.name as bank_name, b.logo_emoji
            FROM deposits d JOIN banks b ON d.bank_id=b.id
            ORDER BY d.max_rate DESC
        """).fetchall()
        return [dict(r) for r in rows]


# ──────────────────────────────────────────────────────────────
# To'lov CRUD
# ──────────────────────────────────────────────────────────────

def create_payment(user_id: int, provider: str, amount: int, sub_type: str) -> int:
    with get_connection() as conn:
        c = conn.execute("""
            INSERT INTO payments (user_id, provider, amount, sub_type)
            VALUES (?,?,?,?)
        """, (user_id, provider, amount, sub_type))
        conn.commit()
        return c.lastrowid


def confirm_payment(payment_id: int, transaction_id: str):
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM payments WHERE id=?", (payment_id,)).fetchone()
        if not row:
            return
        conn.execute("""
            UPDATE payments SET status='paid', transaction_id=?, paid_at=datetime('now')
            WHERE id=?
        """, (transaction_id, payment_id))
        conn.commit()
        activate_subscription(row["user_id"], row["sub_type"])


# ──────────────────────────────────────────────────────────────
# AI suhbat tarixi
# ──────────────────────────────────────────────────────────────

def save_ai_message(user_id: int, role: str, message: str):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO ai_sessions (user_id, role, message) VALUES (?,?,?)",
            (user_id, role, message)
        )
        conn.commit()


def get_ai_history(user_id: int, limit=10) -> List[Dict]:
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT role, message FROM ai_sessions
            WHERE user_id=?
            ORDER BY id DESC LIMIT ?
        """, (user_id, limit)).fetchall()
        return [{"role": r["role"], "content": r["message"]} for r in reversed(rows)]


def clear_ai_history(user_id: int):
    with get_connection() as conn:
        conn.execute("DELETE FROM ai_sessions WHERE user_id=?", (user_id,))
        conn.commit()


# ──────────────────────────────────────────────────────────────
# Statistika
# ──────────────────────────────────────────────────────────────

def log_event(event: str, user_id: int = None, data: str = None):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO stats (event, user_id, data) VALUES (?,?,?)",
            (event, user_id, data)
        )
        conn.commit()


def get_stats() -> Dict:
    with get_connection() as conn:
        total_users   = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        active_subs   = conn.execute("SELECT COUNT(*) FROM users WHERE is_subscribed=1").fetchone()[0]
        total_revenue = conn.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='paid'").fetchone()[0]
        calc_count    = conn.execute("SELECT COUNT(*) FROM stats WHERE event='calc_used'").fetchone()[0]
        ai_count      = conn.execute("SELECT COUNT(*) FROM stats WHERE event='ai_used'").fetchone()[0]
        today_users   = conn.execute(
            "SELECT COUNT(DISTINCT user_id) FROM stats WHERE date(created_at)=date('now')"
        ).fetchone()[0]
        return {
            "total_users":   total_users,
            "active_subs":   active_subs,
            "total_revenue": total_revenue,
            "calc_count":    calc_count,
            "ai_count":      ai_count,
            "today_users":   today_users,
        }
